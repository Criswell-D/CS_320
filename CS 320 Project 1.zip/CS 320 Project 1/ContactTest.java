/*************************
 * Name: 	Devin Criswell
 * Course: 	CS-320 
 * Date: 	June 12, 2024
 *************************/
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ContactTest {
    @Test
    public void testValidContactCreation() {
        Contact contact = new Contact("1001", "Tom", "Harry", "1234567890", "123 Hollywood Blvd");
        assertEquals("1001", contact.getContactId());
        assertEquals("Tom", contact.getFirstName());
        assertEquals("Harry", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Hollywood Blvd", contact.getAddress());
    }

    @Test
    public void testInvalidContactId() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "Tom", "Harry", "1234567890", "123 Hollywood Blvd"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "Tom", "Harry", "1234567890", "123 Hollywood Blvd"));
    }

    @Test
    public void testInvalidFirstName() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("1002", null, "Harry", "1234567890", "123 Hollywood Blvd"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1002", "TomTomTomTom", "Harry", "1234567890", "123 Hollywood Blvd"));
    }

    @Test
    public void testInvalidLastName() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("1003", "Tom", null, "1234567890", "123 Hollywood Blvd"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1003", "Tom", "HarryHarryHarry", "1234567890", "123 Hollywood Blvd"));
    }

    @Test
    public void testInvalidPhone() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("1004", "Tom", "Harry", null, "123 Hollywood Blvd"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1004", "Tom", "Harry", "12345678901", "123 Hollywood Blvd"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1004", "Tom", "Harry", "12345678", "123 Hollywood Blvd"));
    }

    @Test
    public void testInvalidAddress() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("1005", "Tom", "Harry", "1234567890", null));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1005", "Tom", "Harry", "1234567890", "123 Hollywood Blvd Hollywood Blvd Hollywood Blvd"));
    }
}
