/*************************
 * Name: 	Devin Criswell
 * Course: 	CS-320 
 * Date: 	June 12, 2024
 *************************/
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
    private ContactService contactService;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
    }

    @Test
    public void testAddContact() {
        Contact contact = new Contact("1234", "Alice", "Smith", "1112223333", "742 Evergreen Terrace");
        contactService.addContact(contact);
        assertEquals(contact, contactService.getContact("1234"));
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("5678", "Bob", "Johnson", "2223334444", "123 Elm Street");
        contactService.addContact(contact);
        contactService.deleteContact("5678");
        assertThrows(IllegalArgumentException.class, () -> contactService.getContact("5678"));
    }

    @Test
    public void testUpdateContact() {
        Contact contact = new Contact("9012", "Charlie", "Brown", "3334445555", "456 Oak Street");
        contactService.addContact(contact);
        contactService.updateContact("9012", "Carlos", "Bruno", "4445556666", "789 Pine Street");

        Contact updatedContact = contactService.getContact("9012");
        assertEquals("Carlos", updatedContact.getFirstName());
        assertEquals("Bruno", updatedContact.getLastName());
        assertEquals("4445556666", updatedContact.getPhone());
        assertEquals("789 Pine Street", updatedContact.getAddress());
    }

    @Test
    public void testInvalidContactConstraints() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "Dave", "Clark", "5556667777", "101 Maple Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("7890", null, "Clark", "5556667777", "101 Maple Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("7890", "Dave", null, "5556667777", "101 Maple Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("7890", "Dave", "Clark", null, "101 Maple Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("7890", "Dave", "Clark", "5556667777", null));
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "Dave", "Clark", "5556667777", "101 Maple Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("7890", "DavidDavidDavid", "Clark", "5556667777", "101 Maple Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("7890", "Dave", "ClarkClarkClarkClark", "5556667777", "101 Maple Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("7890", "Dave", "Clark", "55566677777", "101 Maple Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("7890", "Dave", "Clark", "5556667777", "123 Maple Street123 Maple Street123 Maple Street123 Maple Street"));
    }
}